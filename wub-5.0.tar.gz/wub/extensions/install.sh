for i in *.tm; do ln -s `pwd`/$i /usr/lib/tcl8/8.5/; done

